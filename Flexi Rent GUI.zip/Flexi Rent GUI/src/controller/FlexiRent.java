/*
 Start class for starting the program
 */
package controller;

import view.main;

public class FlexiRent {

    //Start the program
    public static void main(String[] args) {
        
        new main().setVisible(true);
    }
    
}
