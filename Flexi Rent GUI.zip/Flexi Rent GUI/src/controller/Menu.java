//This clss used to implement menu options
package controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import model.Database;


public class Menu {

    private final JFileChooser chooser = new JFileChooser();
    String name, type, status, room, description;
    Database db = new Database();
    ArrayList<String> arrayList = new ArrayList<>();
    Connection conn;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet resultSet;

    public void importData() {
        try {
            BufferedReader br = null;
            byte[] image = new byte[1024];

            final int selector = chooser.showOpenDialog(null);
            if (selector != JFileChooser.APPROVE_OPTION) {
                return;
            }
            final File f = chooser.getSelectedFile();

            br = new BufferedReader(new FileReader("File/export_data.txt"));
            String line = null;
            while ((line = br.readLine()) != null) {
                if (line != null && !line.equals("")) {
                    String loadinfor[] = line.split(",");
                    name = loadinfor[0];
                    type = loadinfor[1];
                    status = loadinfor[2];
                    room = loadinfor[3];
                    description = loadinfor[4];
                    db.importInfor(name, type, status, room, description, image);
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void exportData() {
        String sql = "select * from rental_property";
        try {
            conn = db.connect();
            preparedStatement = conn.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                String a = resultSet.getString("name");
                String b = resultSet.getString("type");
                String c = resultSet.getString("status");
                String d = resultSet.getString("room");
                String e = resultSet.getString("description");
                arrayList.add(a + "," + b + "," + c + "," + d + "," + e + "\n");

            }
            save(arrayList, "File/export_data.txt");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void save(ArrayList<String> arrayList, String fileexport_datatxt) {
        
        BufferedWriter bw = null;

        try {
            File f = new File(fileexport_datatxt);
            bw = new BufferedWriter(new FileWriter(f, true));
            for (String s : arrayList) {
                bw.write(s);
                bw.newLine();
            }
            bw.close();
            JOptionPane.showMessageDialog(null, "Export Successfully Done..!!");
        } catch (IOException ex) {
            Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void quit() {
        
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure to exit the program?", "Quit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (confirm == 0) {

            System.exit(0);

        }
    }

}
