/* This class is used for Database operations*/

package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class Database {

    public Connection connect() {
    	 String path = "Java/FlexiRent/database/Flexirent.db";
         String url = "jdbc:sqlite:file:database/Flexirent.db";
         
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
            createTable(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    private void createTable(String url) {
        String sql = "CREATE TABLE IF NOT EXISTS rental_property (\n"
                + "	id integer PRIMARY KEY,\n"
                + "	name text NOT NULL,\n"
                + "	type text NOT NULL,\n"
                + "	status text NOT NULL,\n"
                + "	room text NOT NULL,\n"
                + "	image BLOB,\n"
                + "	description text\n"
                + ");";
        try (Connection conn = DriverManager.getConnection(url);
                Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            createRental(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void createRental(String url) {
        String sql = "CREATE TABLE IF NOT EXISTS rental_records (\n"
                + "	id integer PRIMARY KEY,\n"
                + "	name text NOT NULL,\n"
                + "	customer_id text\n"
                + ");";
        try (Connection conn = DriverManager.getConnection(url);
                Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void addProperty(String aa, String bb, String cc, String dd, String ee, byte[] image) {

        String sql = "INSERT INTO rental_property(name,status,type,room,description,image) VALUES(?,?,?,?,?,?)";

        try (
                Connection conn = this.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, aa);
            pstmt.setString(2, bb);
            pstmt.setString(3, cc);
            pstmt.setString(4, dd);
            pstmt.setString(5, ee);
            pstmt.setBytes(6, image);
            pstmt.executeUpdate();
            System.out.println("Saved..!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void importInfor(String name, String type, String status, String room, String description, byte[] image) {

        String sql = "INSERT INTO rental_property(name,status,type,room,description,image) VALUES(?,?,?,?,?,?)";

        try (
                Connection conn = this.connect();
                PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, status);
            pstmt.setString(3, type);
            pstmt.setString(4, room);
            pstmt.setString(5, description);
            pstmt.setBytes(6, image);
            pstmt.executeUpdate();
            System.out.println("Saved..!!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void rent(String name, int customer, String rented) {
        
        try {
            Connection conn = this.connect();
            String query = " insert into rental_records (name, customer_id)"
                    + " values (?, ?)";
           PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, customer);
            preparedStatement.execute();

            String q2 = "update rental_property set status=? where name=?";

            preparedStatement = conn.prepareStatement(q2);
            preparedStatement.setString(1, rented);
            preparedStatement.setString(2, name);
            preparedStatement.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(null, "Rental Record Added..!!");
//                    clearData();
        } catch (Exception e) {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }
    }

    public void returnProperty(String name, String property) {
        try {
            Connection conn = this.connect();
            String q2 = "update rental_property set status=? where name=?";
           PreparedStatement preparedStatement = conn.prepareStatement(q2);
            preparedStatement.setString(1, "Available");
            preparedStatement.setString(2, property);
            preparedStatement.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(null, "Rental Record Returned..!!");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Got an exception!"+e.getMessage());
        }
    }

    public void performMaintenance(String name, String maintenance) {
        
        try {
            Connection conn = this.connect();
            String q2 = "update rental_property set status=? where name=?";
           PreparedStatement preparedStatement = conn.prepareStatement(q2);
            preparedStatement.setString(1, maintenance);
            preparedStatement.setString(2, name);
            preparedStatement.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(null, "Rental Property set for Maintenance ..!!");

        } catch (Exception e) {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }
    }

    public void completeMaintenance(String name, String available) {
        
        try {
            Connection conn = this.connect();
            String q2 = "update rental_property set status=? where name=?";
           PreparedStatement preparedStatement = conn.prepareStatement(q2);
            preparedStatement.setString(1, available);
            preparedStatement.setString(2, name);
            preparedStatement.executeUpdate();
            conn.close();
            JOptionPane.showMessageDialog(null, "Rental Property Maintenance Completed Successfully..!!");

        } catch (Exception e) {
            System.err.println("Got an exception!");
            System.err.println(e.getMessage());
        }
    }

}
