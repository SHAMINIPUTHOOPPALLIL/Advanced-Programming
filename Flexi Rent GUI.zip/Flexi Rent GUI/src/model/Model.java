/*This clsss is used for assigning values to the model*/
package model;
public class Model {
    
    private String name,type,status,room;
    private byte[] item_image;
    private String description;

    public Model() {
    }

    public Model(String name, String type, String status, String room, byte[] item_image, String description) {
        this.name = name;
        this.type = type;
        this.status = status;
        this.room = room;
        this.item_image = item_image;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public byte[] getItem_image() {
        return item_image;
    }

    public void setItem_image(byte[] item_image) {
        this.item_image = item_image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
}
