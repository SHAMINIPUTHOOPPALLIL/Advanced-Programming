/*This is the adapter class for database retrieval operations*/
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Keeprawteach
 */
public class MyAdapter {
    Database db=new Database();
    Connection conn;
    Statement stmt ;
    ResultSet resultSet;
    
    public ArrayList<Model> loadDataHere() {
        
        ArrayList<Model> arrayList = new ArrayList<Model>();
        String sql = "select * from rental_property";
        try {
            conn=db.connect();
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(sql);
            Model product;
            while (resultSet.next()) {
                product = new Model(resultSet.getString("name"),
                        resultSet.getString("type"),
                        resultSet.getString("status"),
                        resultSet.getString("room"),
                        resultSet.getBytes("image"),
                        resultSet.getString("description"));
                arrayList.add(product);
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }

    public ArrayList<Model> loadType(String type) {
        
        ArrayList<Model> arrayList = new ArrayList<Model>();
        String sql = "select * from rental_property where type='"+type+"'";
        try {
            conn=db.connect();
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(sql);
            Model product;
            while (resultSet.next()) {
                product = new Model(resultSet.getString("name"),
                        resultSet.getString("type"),
                        resultSet.getString("status"),
                        resultSet.getString("room"),
                        resultSet.getBytes("image"),
                        resultSet.getString("description"));
                arrayList.add(product);
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }

    public ArrayList<Model> loadRoom(String room) {
        
        ArrayList<Model> arrayList = new ArrayList<Model>();
        String sql = "select * from rental_property where room='"+room+"'";
        try {
            conn=db.connect();
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(sql);
            Model product;
            while (resultSet.next()) {
                product = new Model(resultSet.getString("name"),
                        resultSet.getString("type"),
                        resultSet.getString("status"),
                        resultSet.getString("room"),
                        resultSet.getBytes("image"),
                        resultSet.getString("description"));
                arrayList.add(product);
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }

    public ArrayList<Model> loadState(String state) {
        
        ArrayList<Model> arrayList = new ArrayList<Model>();
        String sql = "select * from rental_property where status='"+state+"'";
        try {
            conn=db.connect();
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(sql);
            Model product;
            while (resultSet.next()) {
                product = new Model(resultSet.getString("name"),
                        resultSet.getString("type"),
                        resultSet.getString("status"),
                        resultSet.getString("room"),
                        resultSet.getBytes("image"),
                        resultSet.getString("description"));
                arrayList.add(product);
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }
}
