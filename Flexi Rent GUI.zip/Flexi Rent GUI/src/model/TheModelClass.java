//This class act as adapter class for database column retrieval
package model;

import javax.swing.Icon;
import javax.swing.table.AbstractTableModel;


public class TheModelClass extends AbstractTableModel {

    private Object[][] rows;
    private String[] columns;

    public TheModelClass() {
    }

    public TheModelClass(Object[][] rows, String[] columns) {
        this.rows = rows;
        this.columns = columns;
    }

    public Class getColumnClass(int column) {
        if (column == 4) {
            return Icon.class;
        } else {
            return getValueAt(0, column).getClass();
        }
    }

    @Override
    public int getRowCount() {
        return this.rows.length;
    }

    @Override
    public int getColumnCount() {
        return this.columns.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return this.rows[rowIndex][columnIndex];
    }

    public String getColumnName(int col) {
        return this.columns[col];
    }

    
}
